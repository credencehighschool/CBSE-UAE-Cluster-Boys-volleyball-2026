/**
 * CBSE UAE Cluster Boys Volleyball Championship — Backend (Google Apps Script)
 * ------------------------------------------------------------------------
 * This is the file that was MISSING from your upload. It reads/writes a
 * Google Sheet and serves JSON to every page via the API URL in config.js.
 *
 * SETUP (one time):
 *  1. Create a new Google Sheet. Extensions → Apps Script. Paste this file in.
 *  2. Run `setup` once (Run ▸ setup) to create all tabs with headers, and to
 *     set the owner password. It will ask for permission the first time.
 *  3. Deploy ▸ New deployment ▸ Type: Web app.
 *       Execute as: Me
 *       Who has access: Anyone
 *  4. Copy the Web app URL into config.js as `apiUrl`.
 *  5. Every time you Deploy ▸ Manage deployments ▸ edit ▸ new version after
 *     changing this file, or your site will keep hitting the old code.
 *
 * To change the admin password later, run `setPassword` with a new value,
 * or just edit the "OwnerPassword" row on the Settings sheet directly.
 */

const SHEETS = {
  OVERVIEW: "Overview",
  NOTICES: "Notices",
  MATCHES: "Matches",
  COURTS: "Courts",
  TEAMS: "Teams",
  GALLERY: "Gallery",
  BRACKET: "Bracket",
  MEDALS: "Medals",
  AWARDS: "Awards",
  SETTINGS: "Settings"
};

const HEADERS = {
  Overview: ["participatingSchools", "totalAthletes", "totalTeams", "championshipTitle", "overviewNote"],
  Notices: ["id", "title", "message", "updatedAt"],
  Matches: ["matchId", "category", "status", "currentSet", "date", "time", "court", "teamA", "teamB", "scoreA", "scoreB", "set1", "set2", "set3", "set4", "set5", "winner", "updatedAt", "matchNo", "roundNo"],
  Courts: ["court", "category", "format", "date", "time", "teamA", "teamB", "status", "currentSet", "pointsA", "pointsB", "setsWonA", "setsWonB", "set1", "set2", "set3", "set4", "set5", "winner", "updatedAt", "matchNo", "roundNo"],
  Teams: ["category", "slNo", "schoolName", "schoolCode", "emirate", "present", "updatedAt"],
  Gallery: ["id", "url", "caption", "updatedAt"],
  Bracket: ["id", "category", "stage", "teamA", "scoreA", "teamB", "scoreB", "winner", "updatedAt", "roundOrder"],
  Medals: ["id", "category", "position", "school", "updatedAt"],
  Awards: ["id", "icon", "award", "student", "school", "category", "updatedAt"],
  Settings: ["key", "value"]
};

const COURT_NAMES = ["Court-1", "Court-2", "Court-3", "Court-4"];

/* ---------------------------- SETUP ---------------------------- */

function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  Object.keys(HEADERS).forEach(name => {
    let sheet = ss.getSheetByName(name);
    if (!sheet) sheet = ss.insertSheet(name);
    const headers = HEADERS[name];
    const lastCol = Math.max(sheet.getLastColumn(), 1);
    const existing = sheet.getRange(1, 1, 1, lastCol).getValues()[0].filter(String);
    if (existing.length === 0) {
      sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
      sheet.setFrozenRows(1);
    } else {
      // Migration: if this sheet already exists from an earlier version of
      // Code.gs, append any newly-added columns at the end without touching
      // existing data or column order.
      const missing = headers.filter(h => existing.indexOf(h) === -1);
      if (missing.length) {
        sheet.getRange(1, existing.length + 1, 1, missing.length).setValues([missing]);
      }
    }
  });
  // Remove the default "Sheet1" if it's empty and unused
  const def = ss.getSheetByName("Sheet1");
  if (def && def.getLastRow() === 0) ss.deleteSheet(def);

  // CRITICAL FIX: Google Sheets auto-detects strings like "2-7" or "3-1" and
  // silently converts them into calendar dates. Force these columns to plain
  // text so a set score can never be reinterpreted as a date again. This only
  // protects values entered from now on — any cell that's already been
  // corrupted into a date needs to be retyped by hand once.
  forceTextColumns(getSheet(SHEETS.MATCHES), HEADERS.Matches, ["date", "time", "set1", "set2", "set3", "set4", "set5"], 3000);
  forceTextColumns(getSheet(SHEETS.COURTS), HEADERS.Courts, ["date", "time", "set1", "set2", "set3", "set4", "set5"], 3000);

  seedCourts();
  setPassword("changeme123"); // ⚠️ CHANGE THIS — see setPassword() below
  SpreadsheetApp.getUi().alert("Setup complete (or migrated). Tabs created/updated, date/score columns locked to plain text. Default owner password is 'changeme123' if this is a first run — run setPassword('yourNewPassword') to change it, then redeploy.");
}

function forceTextColumns(sheet, headers, fieldNames, numRows) {
  fieldNames.forEach(f => {
    const colIndex = headers.indexOf(f);
    if (colIndex === -1) return;
    sheet.getRange(2, colIndex + 1, numRows, 1).setNumberFormat("@");
  });
}

// Creates the 4 fixed court rows (Court-1..Court-4) if they don't already exist.
function seedCourts() {
  const sheet = getSheet(SHEETS.COURTS);
  const values = sheet.getDataRange().getValues();
  const existingCourts = values.slice(1).map(r => r[0]);
  COURT_NAMES.forEach(court => {
    if (!existingCourts.includes(court)) {
      const row = HEADERS.Courts.map(h => {
        if (h === "court") return court;
        if (h === "status") return "Idle";
        if (["currentSet", "pointsA", "pointsB", "setsWonA", "setsWonB"].includes(h)) return 0;
        return "";
      });
      sheet.appendRow(row);
    }
  });
}

function setPassword(newPassword) {
  const sheet = getSheet(SHEETS.SETTINGS);
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === "OwnerPassword") {
      sheet.getRange(i + 1, 2).setValue(newPassword);
      return;
    }
  }
  sheet.appendRow(["OwnerPassword", newPassword]);
}

function getOwnerPassword() {
  const sheet = getSheet(SHEETS.SETTINGS);
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === "OwnerPassword") return String(data[i][1]);
  }
  return null;
}

function getSheet(name) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(name);
  if (!sheet) throw new Error("Sheet '" + name + "' not found. Run setup() first.");
  return sheet;
}

/* ------------------------- HTTP ENTRY POINTS ------------------------- */

function doGet(e) {
  const action = (e.parameter.action || "").toLowerCase();
  let payload;
  try {
    switch (action) {
      case "all": payload = { notices: readAll(SHEETS.NOTICES) }; break;
      case "gallery": payload = { gallery: readAll(SHEETS.GALLERY) }; break;
      case "live": payload = { live: readMatchesByStatus(["Live"]) }; break;
      case "results": payload = { results: readMatchesByStatus(["Completed"]) }; break;
      case "medals": payload = { medals: readAll(SHEETS.MEDALS) }; break;
      case "awards": payload = { awards: readAll(SHEETS.AWARDS) }; break;
      case "bracket": payload = { bracket: readAll(SHEETS.BRACKET) }; break;
      case "courts": payload = { courts: readAll(SHEETS.COURTS) }; break;
      case "teams": payload = { teams: readAll(SHEETS.TEAMS) }; break;
      case "scheduled": payload = { scheduled: readMatchesByStatus(["Scheduled"]) }; break;
      case "autostandings": payload = { standings: computeStandings() }; break;
      case "overview": payload = { overview: readAll(SHEETS.OVERVIEW)[0] || {} }; break;
      default: payload = { error: "Unknown action: " + action };
    }
  } catch (err) {
    payload = { error: String(err) };
  }
  return jsonOut(payload);
}

function doPost(e) {
  let data;
  try {
    data = JSON.parse(e.postData.contents);
  } catch (err) {
    return jsonOut({ message: "Invalid request body." });
  }

  const ownerPassword = getOwnerPassword();

  // Login check happens before the generic password gate below, since a
  // failed login attempt isn't trying to save anything.
  if (data.action === "checkLogin") {
    return jsonOut({ ok: !!ownerPassword && data.password === ownerPassword });
  }

  if (!ownerPassword || data.password !== ownerPassword) {
    return jsonOut({ message: "Incorrect password. Nothing was saved." });
  }

  try {
    switch (data.action) {
      case "saveOverview": return jsonOut(saveOverview(data));
      case "saveMatchPhase1": return jsonOut(saveMatch(data));
      case "saveNotice": return jsonOut(saveKeyed(SHEETS.NOTICES, HEADERS.Notices, data));
      case "saveGallery": return jsonOut(saveKeyed(SHEETS.GALLERY, HEADERS.Gallery, data));
      case "saveBracket": return jsonOut(saveKeyed(SHEETS.BRACKET, HEADERS.Bracket, data));
      case "saveMedal": return jsonOut(saveKeyed(SHEETS.MEDALS, HEADERS.Medals, data));
      case "saveAward": return jsonOut(saveKeyed(SHEETS.AWARDS, HEADERS.Awards, data));
      case "startCourtMatch": return jsonOut(withLock(() => startCourtMatch(data)));
      case "addPoint": return jsonOut(withLock(() => addPoint(data)));
      case "removePoint": return jsonOut(withLock(() => removePoint(data)));
      case "endSet": return jsonOut(withLock(() => endSet(data)));
      case "resetCourt": return jsonOut(withLock(() => resetCourt(data)));
      case "editCourt": return jsonOut(withLock(() => editCourt(data)));
      case "saveTeams": return jsonOut(withLock(() => saveTeams(data)));
      default: return jsonOut({ message: "Unknown save action: " + data.action });
    }
  } catch (err) {
    return jsonOut({ message: "Save failed: " + String(err) });
  }
}

// Every court-scoring action is wrapped in a lock so two rapid taps (or two
// different courts' admins saving at the same instant) never corrupt a row —
// each request waits its turn instead of overlapping.
function withLock(fn) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    return fn();
  } finally {
    lock.releaseLock();
  }
}

function jsonOut(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/* ----------------------------- READ HELPERS ----------------------------- */

function readAll(sheetName) {
  const sheet = getSheet(sheetName);
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];
  const headers = values[0];
  return values.slice(1)
    .filter(row => row.join("") !== "")
    .map(row => {
      const obj = {};
      headers.forEach((h, i) => obj[h] = row[i]);
      return obj;
    });
}

function readMatchesByStatus(statuses) {
  return readAll(SHEETS.MATCHES).filter(m => statuses.includes(String(m.status)));
}

/* ----------------------------- WRITE HELPERS ----------------------------- */

// Generic upsert-by-id for simple sheets keyed on their first column ("id").
function saveKeyed(sheetName, headers, data) {
  const sheet = getSheet(sheetName);
  const idField = headers[0];
  const values = sheet.getDataRange().getValues();
  const idCol = 0;
  let rowIndex = -1;
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][idCol]) === String(data[idField] || data.id)) { rowIndex = i + 1; break; }
  }
  const row = headers.map(h => {
    if (h === "updatedAt") return new Date();
    if (h === idField) return data[idField] !== undefined ? data[idField] : data.id;
    return data[h] !== undefined ? data[h] : "";
  });
  if (rowIndex === -1) sheet.appendRow(row);
  else sheet.getRange(rowIndex, 1, 1, row.length).setValues([row]);
  return { message: "Saved." };
}

function saveMatch(data) {
  const sheet = getSheet(SHEETS.MATCHES);
  const headers = HEADERS.Matches;
  const values = sheet.getDataRange().getValues();
  let rowIndex = -1;
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][0]) === String(data.matchId)) { rowIndex = i + 1; break; }
  }
  const row = headers.map(h => {
    if (h === "updatedAt") return new Date();
    if (h === "matchId") return data.matchId;
    return data[h] !== undefined ? data[h] : "";
  });
  if (rowIndex === -1) sheet.appendRow(row);
  else sheet.getRange(rowIndex, 1, 1, row.length).setValues([row]);
  return { message: "Match saved." };
}

/* ----------------------------- TEAMS / ATTENDANCE -----------------------------
   One roster per category (Boys U-14/U-17/U-19). Saving a category replaces
   ALL its rows in one go — simplest way to keep SL No order and attendance
   in sync without juggling per-row IDs. Also gives Live scoring a clean,
   consistent list of official school names (see admin.html datalist). */

function saveTeams(data) {
  const sheet = getSheet(SHEETS.TEAMS);
  const headers = HEADERS.Teams;
  const values = sheet.getDataRange().getValues();
  const keep = values.slice(1).filter(r => String(r[0]) !== String(data.category) && r.join("") !== "");
  const newRows = (data.teams || []).map((t, i) => headers.map(h => {
    if (h === "updatedAt") return new Date();
    if (h === "category") return data.category;
    if (h === "slNo") return i + 1;
    return t[h] !== undefined ? t[h] : "";
  }));
  const allRows = keep.concat(newRows);
  sheet.clearContents();
  sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
  if (allRows.length) sheet.getRange(2, 1, allRows.length, headers.length).setValues(allRows);
  return { message: "Saved " + newRows.length + " schools for " + data.category + "." };
}

function saveOverview(data) {
  const sheet = getSheet(SHEETS.OVERVIEW);
  const headers = HEADERS.Overview;
  const row = headers.map(h => data[h] !== undefined ? data[h] : "");
  if (sheet.getLastRow() < 2) sheet.appendRow(row);
  else sheet.getRange(2, 1, 1, row.length).setValues([row]);
  return { message: "Overview saved." };
}

/* ----------------------------- COURTS (live point-by-point scoring) -----------------------------
   Each of the 4 rows (Court-1..Court-4) holds ONE in-progress match. Admins tap +1/-1 as points
   are scored; "End Set" locks the set into history and starts the next one; when the match is
   decided (2 sets won for Best-of-3, 3 for Best-of-5) it auto-publishes into the Matches sheet
   so Results and Standings pick it up automatically — no manual re-entry. */

function getCourtRow(sheet, court) {
  const values = sheet.getDataRange().getValues();
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][0]) === String(court)) return { rowIndex: i + 1, values: values[i] };
  }
  throw new Error("Unknown court: " + court + ". Run setup() to (re)create the 4 court rows.");
}

function courtObjFromRow(row) {
  const obj = {};
  HEADERS.Courts.forEach((h, i) => obj[h] = row[i]);
  return obj;
}

function writeCourtRow(sheet, rowIndex, obj) {
  const row = HEADERS.Courts.map(h => h === "updatedAt" ? new Date() : (obj[h] !== undefined ? obj[h] : ""));
  sheet.getRange(rowIndex, 1, 1, row.length).setValues([row]);
}

function startCourtMatch(data) {
  const sheet = getSheet(SHEETS.COURTS);
  const { rowIndex } = getCourtRow(sheet, data.court);
  const obj = {
    court: data.court,
    category: data.category || "",
    format: data.format || "Best of 3",
    date: data.date || "",
    time: data.time || "",
    teamA: data.teamA || "",
    teamB: data.teamB || "",
    status: "Live",
    currentSet: 1,
    pointsA: 0,
    pointsB: 0,
    setsWonA: 0,
    setsWonB: 0,
    set1: "", set2: "", set3: "", set4: "", set5: "",
    winner: "",
    matchNo: data.matchNo || "",
    roundNo: data.roundNo || ""
  };
  writeCourtRow(sheet, rowIndex, obj);
  return { message: data.court + ": match started." };
}

function addPoint(data) {
  const sheet = getSheet(SHEETS.COURTS);
  const { rowIndex, values } = getCourtRow(sheet, data.court);
  const obj = courtObjFromRow(values);
  if (obj.status !== "Live") return { message: "Court is not live — start a match first." };
  const field = data.team === "A" ? "pointsA" : "pointsB";
  obj[field] = Math.max(0, (Number(obj[field]) || 0) + 1);
  writeCourtRow(sheet, rowIndex, obj);
  return { message: "Point added.", pointsA: obj.pointsA, pointsB: obj.pointsB };
}

function removePoint(data) {
  const sheet = getSheet(SHEETS.COURTS);
  const { rowIndex, values } = getCourtRow(sheet, data.court);
  const obj = courtObjFromRow(values);
  const field = data.team === "A" ? "pointsA" : "pointsB";
  obj[field] = Math.max(0, (Number(obj[field]) || 0) - 1);
  writeCourtRow(sheet, rowIndex, obj);
  return { message: "Point removed.", pointsA: obj.pointsA, pointsB: obj.pointsB };
}

function setsToWin(format) {
  return String(format).includes("5") ? 3 : 2;
}

function endSet(data) {
  const sheet = getSheet(SHEETS.COURTS);
  const { rowIndex, values } = getCourtRow(sheet, data.court);
  const obj = courtObjFromRow(values);
  if (obj.status !== "Live") return { message: "Court is not live." };

  const pA = Number(obj.pointsA) || 0, pB = Number(obj.pointsB) || 0;
  const setNum = Number(obj.currentSet) || 1;
  if (setNum > 5) return { message: "Match already has 5 sets recorded." };
  obj["set" + setNum] = pA + "-" + pB;

  if (pA > pB) obj.setsWonA = (Number(obj.setsWonA) || 0) + 1;
  else obj.setsWonB = (Number(obj.setsWonB) || 0) + 1;

  obj.pointsA = 0; obj.pointsB = 0;
  obj.currentSet = setNum + 1;

  const need = setsToWin(obj.format);
  if (obj.setsWonA >= need || obj.setsWonB >= need) {
    obj.status = "Completed";
    obj.winner = obj.setsWonA >= need ? obj.teamA : obj.teamB;
    writeCourtRow(sheet, rowIndex, obj);
    publishCourtToMatches(obj);
    return { message: "Set saved. Match complete — " + obj.winner + " wins. Published to Results." };
  }

  writeCourtRow(sheet, rowIndex, obj);
  return { message: "Set " + setNum + " saved (" + (pA + "-" + pB) + "). Set " + obj.currentSet + " is live." };
}

function resetCourt(data) {
  const sheet = getSheet(SHEETS.COURTS);
  const { rowIndex } = getCourtRow(sheet, data.court);
  writeCourtRow(sheet, rowIndex, {
    court: data.court, category: "", format: "", date: "", time: "",
    teamA: "", teamB: "", status: "Idle", currentSet: 0, pointsA: 0, pointsB: 0,
    setsWonA: 0, setsWonB: 0, set1: "", set2: "", set3: "", set4: "", set5: "", winner: "",
    matchNo: "", roundNo: ""
  });
  return { message: data.court + " cleared and ready for the next match." };
}

// Manual override for corrections — lets the admin fix any field on a court directly.
function editCourt(data) {
  const sheet = getSheet(SHEETS.COURTS);
  const { rowIndex, values } = getCourtRow(sheet, data.court);
  const obj = courtObjFromRow(values);
  HEADERS.Courts.forEach(h => { if (data[h] !== undefined) obj[h] = data[h]; });
  writeCourtRow(sheet, rowIndex, obj);
  if (obj.status === "Completed") publishCourtToMatches(obj);
  return { message: data.court + " updated." };
}

// Pushes a completed court match into the Matches sheet using the SAME schema
// the old single-match form used — so Results and Standings need no changes.
function publishCourtToMatches(court) {
  const sheet = getSheet(SHEETS.MATCHES);
  const matchId = "AUTO-" + court.court + "-" + new Date().getTime();
  const row = HEADERS.Matches.map(h => {
    if (h === "updatedAt") return new Date();
    if (h === "matchId") return matchId;
    if (h === "status") return "Completed";
    if (h === "court") return court.court;
    if (h === "scoreA") return court.setsWonA;
    if (h === "scoreB") return court.setsWonB;
    if (h === "currentSet") return "";
    return court[h] !== undefined ? court[h] : "";
  });
  sheet.appendRow(row);
}

/* ----------------------------- STANDINGS ----------------------------- */

// FIVB-style points: 3-0/3-1 win = 3pts / 0pts. 3-2 win = 2pts / 1pt.
function matchPoints(setsWon, setsLost) {
  if (setsWon > setsLost) return (setsWon - setsLost >= 2) ? 3 : 2;
  return (setsLost - setsWon >= 2) ? 0 : 1;
}

function computeStandings() {
  const matches = readMatchesByStatus(["Completed"]);
  const table = {}; // category -> team -> stats

  matches.forEach(m => {
    const category = m.category;
    const setsA = Number(m.scoreA) || 0;
    const setsB = Number(m.scoreB) || 0;
    if (!m.teamA || !m.teamB) return;

    [
      { team: m.teamA, setsFor: setsA, setsAgainst: setsB },
      { team: m.teamB, setsFor: setsB, setsAgainst: setsA }
    ].forEach(side => {
      table[category] = table[category] || {};
      const t = table[category][side.team] = table[category][side.team] || {
        team: side.team, category, played: 0, won: 0, lost: 0, setsFor: 0, setsAgainst: 0, points: 0
      };
      t.played += 1;
      t.setsFor += side.setsFor;
      t.setsAgainst += side.setsAgainst;
      if (side.setsFor > side.setsAgainst) t.won += 1; else t.lost += 1;
      t.points += matchPoints(side.setsFor, side.setsAgainst);
    });
  });

  let rows = [];
  Object.keys(table).forEach(category => {
    const teams = Object.values(table[category]).sort((a, b) =>
      b.points - a.points || (b.setsFor - b.setsAgainst) - (a.setsFor - a.setsAgainst)
    );
    rows = rows.concat(teams);
  });
  return rows;
}
